export DAN_POLICY=2; ./efectiu ~/tracesWorking/400.perlbench-50B.trace.gz
